import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Configuration object directly to avoid import issues
const firebaseConfig = {
  "projectId": "sys-tv",
  "appId": "1:555296180171:web:84c5b6e4d739e37ead584e",
  "apiKey": "AIzaSyBTBJJCLUAtog7PNnAqVgvjI1HLMYA560k",
  "authDomain": "sys-tv.firebaseapp.com",
  "firestoreDatabaseId": "ai-studio-1e7a4472-baec-479a-8867-9c06a4d43cfc",
  "storageBucket": "sys-tv.firebasestorage.app",
  "messagingSenderId": "555296180171"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
