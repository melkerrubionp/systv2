import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Clock, 
  Phone, 
  Globe, 
  Settings, 
  X, 
  Plus, 
  Trash2, 
  TrendingUp,
  MessageSquare,
  Layout,
  Tv,
  Youtube,
  Edit2,
  Lock,
  Menu,
  ChevronRight,
  Maximize
} from 'lucide-react';
import { AppConfig, Slide, SlideType } from './types';
import { QRCodeSVG } from 'qrcode.react';
import { db, auth } from './firebase';
import { doc, onSnapshot, setDoc, getDoc, getDocFromCache, getDocFromServer } from 'firebase/firestore';
import { signInWithPopup, GoogleAuthProvider, onAuthStateChanged, setPersistence, browserLocalPersistence } from 'firebase/auth';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  // We don't necessarily want to crash the whole app with a JSON error in the UI, 
  // but we log it for the agent to see.
}

const DEFAULT_CONFIG: AppConfig = {
  dur: 10,
  tel: '(93) 98113-5624',
  site: 'amsterdamjoias.com.br',
  instagram: '@amsterdamjoiasnp',
  password: 'amsterdam2024',
  slides: [
    { id: '1', type: 'color', color: 'sc-bronze', title: 'Alianças de <em>Ouro</em>', sub: 'Símbolos eternos de amor feitos para durar para sempre', tag: '✦ ETERNIDADE · 18K ✦' },
    { id: '2', type: 'color', color: 'sc-azul', title: 'Anéis de <em>Formatura</em>', sub: 'Mais de 300 modelos para celebrar sua grande conquista', tag: '✦ CONQUISTAS 2025 ✦' },
    { id: '3', type: 'product', title: 'Relógio <em>Premium</em>', sub: 'Edição limitada com acabamento em safira', tag: '✦ EXCLUSIVIDADE ✦', price: 'R$ 2.490,00', src: 'https://picsum.photos/seed/watch/800/800' },
    { id: '4', type: 'color', color: 'sc-vinho', title: 'Joias em <em>Prata</em>', sub: 'A elegância autêntica que brilha junto com você', tag: '✦ COLEÇÃO PRATA 925 ✦' },
    { id: '5', type: 'color', color: 'sc-verde', title: 'Limpeza <em>Ultrassônica</em>', sub: 'Devolvemos o brilho original às suas peças mais queridas', tag: '✦ CUIDADO & BRILHO ✦' },
    { id: '6', type: 'youtube', youtubeId: 'dQw4w9WgXcQ', title: 'Nossa <em>História</em>', sub: 'Conheça o processo artesanal da Amsterdam Joias', tag: '✦ TRADIÇÃO ✦' },
    { id: '7', type: 'color', color: 'sc-roxo', title: 'Parcele em <em>10×</em>', sub: 'Sua joia dos sonhos em condições suaves e especiais', tag: '✦ LUXO ACESSÍVEL ✦' },
  ],
  coms: [
    '✨ Atendemos de segunda a sábado, das 8h às 18h.',
    '💳 Parcele suas compras em até 10× sem juros.',
    '💍 Alianças em ouro 18k com garantia de eternidade.',
    '🎓 Mais de 300 modelos de anéis de formatura.',
    '📲 Peça pelo WhatsApp: (93) 98113-5624',
  ],
  tickers: [
    '✦ Alianças personalizadas em Ouro 18k',
    '✦ Anéis de formatura com mais de 300 modelos',
    '✦ Joias em Prata 925 com rhodiagem',
    '✦ Serviços de conserto e limpeza ultrassônica',
    '✦ Parcelamento em até 10× sem juros',
    '✦ Enviamos para todo o Brasil',
    '✦ Gravação a laser personalizada na hora',
  ],
  nightMode: {
    enabled: true,
    startHour: 19,
    endHour: 7,
    dimLevel: 0.85
  }
};

const COLOR_SCHEMES: Record<string, string> = {
  'sc-bronze': 'linear-gradient(135deg,#fffbf0 0%,#fef3c7 60%,#fde68a 100%)',
  'sc-azul': 'linear-gradient(135deg,#f0f9ff 0%,#e0f2fe 60%,#bae6fd 100%)',
  'sc-vinho': 'linear-gradient(135deg,#fff1f2 0%,#ffe4e6 60%,#fecdd3 100%)',
  'sc-verde': 'linear-gradient(135deg,#f0fdf4 0%,#dcfce7 60%,#bbf7d0 100%)',
  'sc-roxo': 'linear-gradient(135deg,#faf5ff 0%,#f3e8ff 60%,#e9d5ff 100%)',
  'sc-cinza': 'linear-gradient(135deg,#f9fafb 0%,#f3f4f6 60%,#e5e7eb 100%)',
};

const ACCENT_COLORS: Record<string, string> = {
  'sc-bronze': 'rgba(245,158,11,.15)',
  'sc-azul': 'rgba(14,165,233,.15)',
  'sc-vinho': 'rgba(244,63,94,.15)',
  'sc-verde': 'rgba(34,197,94,.12)',
  'sc-roxo': 'rgba(168,85,247,.15)',
  'sc-cinza': 'rgba(107,114,128,.1)',
};

export default function App() {
  const [view, setView] = useState<'display' | 'dashboard'>('display');
  const [isMobile, setIsMobile] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [authError, setAuthError] = useState(false);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [tvPasswordInput, setTvPasswordInput] = useState('');
  const [isTvAdmin, setIsTvAdmin] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('isTvAdmin') === 'true';
    }
    return false;
  });

  useEffect(() => {
    localStorage.setItem('isTvAdmin', String(isTvAdmin));
  }, [isTvAdmin]);

  // Fullscreen listener
  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(err => {
        console.error(`Error attempting to enable full-screen mode: ${err.message}`);
      });
    } else {
      document.exitFullscreen();
    }
  };

  const [config, setConfig] = useState<AppConfig>(DEFAULT_CONFIG);

  const [currentTime, setCurrentTime] = useState(new Date());
  const [currentSlideIdx, setCurrentSlideIdx] = useState(0);
  const [currentComIdx, setCurrentComIdx] = useState(0);
  const [isNight, setIsNight] = useState(false);
  const [activeDuration, setActiveDuration] = useState<number>(DEFAULT_CONFIG.dur);
  const [goldPrice18k, setGoldPrice18k] = useState<string>('Atualizando...');
  const [goldPrice24k, setGoldPrice24k] = useState<string>('Atualizando...');

  const fetchGoldPrice = useCallback(async () => {
    try {
      const response = await fetch('https://economia.awesomeapi.com.br/json/last/XAU-BRL');
      const data = await response.json();
      if (data.XAUBRL && data.XAUBRL.bid) {
        const bid = parseFloat(data.XAUBRL.bid);
        const grama24k = bid / 31.1035;
        const grama18k = (grama24k * 0.75) * 0.70; // Aplicando 30% de redução conforme solicitado
        
        const formatter = new Intl.NumberFormat('pt-BR', {
          style: 'currency',
          currency: 'BRL',
        });
        
        setGoldPrice24k(formatter.format(grama24k));
        setGoldPrice18k(formatter.format(grama18k));
      } else {
        setGoldPrice24k('Indisponível');
        setGoldPrice18k('Indisponível');
      }
    } catch (error) {
      console.error('Erro ao buscar cotação do ouro:', error);
      setGoldPrice24k('Indisponível');
      setGoldPrice18k('Indisponível');
    }
  }, []);

  useEffect(() => {
    fetchGoldPrice();
    const interval = setInterval(fetchGoldPrice, 300000);
    return () => clearInterval(interval);
  }, [fetchGoldPrice]);

  const nextSlide = useCallback(() => {
    setCurrentSlideIdx(prev => (prev + 1) % config.slides.length);
  }, [config.slides.length]);

  // Update active duration when slide changes
  useEffect(() => {
    const currentSlide = config.slides[currentSlideIdx];
    setActiveDuration(currentSlide?.duration || config.dur);
  }, [currentSlideIdx, config.slides, config.dur]);

  // Firebase Sync
  useEffect(() => {
    const docRef = doc(db, 'settings', 'global');
    
    // Test connection
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. The client is offline.");
        }
      }
    };
    testConnection();

    const unsubscribe = onSnapshot(docRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data() as AppConfig;
        // Ensure all slides have IDs
        const slidesWithIds = (data.slides || []).map(s => ({
          ...s,
          id: s.id || crypto.randomUUID()
        }));
        
        setConfig(prev => ({
          ...prev,
          ...data,
          slides: slidesWithIds,
          nightMode: {
            ...prev.nightMode,
            ...(data.nightMode || {})
          }
        }));
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'settings/global');
    });

    return () => unsubscribe();
  }, []);

  // Initialize if empty and admin
  useEffect(() => {
    if (isAdmin && isAuthReady) {
      const checkAndInit = async () => {
        const docRef = doc(db, 'settings', 'global');
        const snap = await getDoc(docRef);
        if (!snap.exists()) {
          await setDoc(docRef, DEFAULT_CONFIG).catch(err => handleFirestoreError(err, OperationType.WRITE, 'settings/global'));
        }
      };
      checkAndInit();
    }
  }, [isAdmin, isAuthReady]);

  // Auth State Listener
  useEffect(() => {
    // Set persistence to local (survives browser restart)
    setPersistence(auth, browserLocalPersistence).catch(err => {
      console.error("Error setting persistence:", err);
    });

    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setIsAuthenticated(true);
        if (user.email === 'melkerrubio@gmail.com') {
          setIsAdmin(true);
        } else {
          setIsAdmin(false);
        }
      } else {
        setIsAuthenticated(false);
        setIsAdmin(false);
      }
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Night Mode Logic
  useEffect(() => {
    const checkNight = () => {
      if (!config.nightMode?.enabled) {
        setIsNight(false);
        return;
      }
      const hour = new Date().getHours();
      const { startHour, endHour } = config.nightMode;
      
      if (startHour > endHour) {
        setIsNight(hour >= startHour || hour < endHour);
      } else {
        setIsNight(hour >= startHour && hour < endHour);
      }
    };
    checkNight();
    const timer = setInterval(checkNight, 60000);
    return () => clearInterval(timer);
  }, [config.nightMode]);

  // Persistence (Removed localStorage, now using Firestore via Dashboard save)
  // useEffect(() => {
  //   localStorage.setItem('amsterdam_config', JSON.stringify(config));
  // }, [config]);

  // Clock
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Mobile Detection
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Slideshow
  useEffect(() => {
    if (view !== 'display' || !config.slides.length) return;
    
    const currentSlide = config.slides[currentSlideIdx];
    if (!currentSlide) {
      setCurrentSlideIdx(0);
      return;
    }
    
    // For direct Video, we let the component handle the transition via onEnded
    if (currentSlide.type === 'video') {
      const safetyTimer = setTimeout(nextSlide, 300000); 
      return () => clearTimeout(safetyTimer);
    }

    const slideDuration = activeDuration * 1000;
    const timer = setTimeout(nextSlide, slideDuration);
    return () => clearTimeout(timer);
  }, [activeDuration, config.slides, currentSlideIdx, view, nextSlide]);

  // Announcements
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentComIdx(prev => (prev + 1) % config.coms.length);
    }, 7000);
    return () => clearInterval(timer);
  }, [config.coms.length]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setView('display');
      if ((e.key === 'd' || e.key === 'D') && !(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement)) {
        setView(prev => prev === 'display' ? 'dashboard' : 'display');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const formatTime = (date: Date) => {
    return {
      hm: `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`,
      sec: `:${String(date.getSeconds()).padStart(2, '0')}`,
      day: new Intl.DateTimeFormat('pt-BR', { weekday: 'long' }).format(date),
      date: `${date.getDate()} de ${new Intl.DateTimeFormat('pt-BR', { month: 'long' }).format(date)} · ${date.getFullYear()}`
    };
  };

  const timeInfo = formatTime(currentTime);

  const handleLogin = async (e?: React.MouseEvent) => {
    e?.preventDefault();
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      if (result.user.email === 'melkerrubio@gmail.com') {
        setIsAuthenticated(true);
        if (isMobile) setView('dashboard');
      } else {
        setAuthError(true);
        setTimeout(() => setAuthError(false), 3000);
        await auth.signOut();
      }
    } catch (error: any) {
      if (error.code === 'auth/popup-closed-by-user') return;
      console.error("Login error:", error);
      alert("Erro no login: " + (error.message || "Verifique se o domínio está autorizado no Firebase Console."));
    }
  };

  const handleAdminLogin = async (e?: React.MouseEvent) => {
    e?.preventDefault();
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      if (error.code === 'auth/popup-closed-by-user') return;
      console.error("Admin login error:", error);
      alert("Erro no login admin: " + (error.message || "Verifique as configurações do Firebase."));
    }
  };

  if (view === 'dashboard') {
    return (
      <Dashboard 
        config={config} 
        setConfig={setConfig} 
        setView={setView} 
        isMobile={isMobile} 
        isAdmin={isAdmin || isTvAdmin}
        isAuthenticated={isAuthenticated}
        onAdminLogin={handleAdminLogin}
        onLogout={() => {
          setIsTvAdmin(false);
          setView('display');
        }}
      />
    );
  }

  if (isMobile) {
    if (!isAuthenticated) {
      return (
        <div className="min-h-screen bg-stone-950 flex flex-col items-center justify-center p-6 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-sm"
          >
            <h1 className="font-playfair text-4xl text-gold-amber italic mb-2">Amsterdam</h1>
            <p className="font-bebas text-xs tracking-[6px] text-stone-500 uppercase mb-12">Acesso Restrito</p>
            
            <div className="space-y-6">
              <button 
                type="button"
                onClick={handleLogin}
                className="w-full bg-white text-stone-900 font-bebas tracking-[2px] py-4 rounded-2xl shadow-lg flex items-center justify-center gap-3 active:scale-95 transition-all"
              >
                <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/action/google.svg" className="w-5 h-5" alt="Google" />
                ENTRAR COM GOOGLE
              </button>
              {authError && (
                <p className="text-red-500 text-[10px] font-bebas tracking-widest animate-pulse uppercase">Acesso negado: Apenas administrador</p>
              )}
            </div>
            
            <p className="mt-12 text-stone-600 text-[10px] font-bebas tracking-widest leading-relaxed">
              ESTE DISPOSITIVO ESTÁ SENDO IDENTIFICADO COMO CELULAR.<br/>
              O ACESSO AO PAINEL É EXCLUSIVO PARA O ADMINISTRADOR.
            </p>
          </motion.div>
        </div>
      );
    }

    return (
      <Dashboard 
        config={config} 
        setConfig={setConfig} 
        setView={setView} 
        isMobile={isMobile} 
        isAdmin={isAdmin || isTvAdmin}
        isAuthenticated={isAuthenticated}
        onAdminLogin={handleAdminLogin}
        onLogout={() => {
          setIsTvAdmin(false);
          setView('display');
        }}
      />
    );
  }

  // TV Display (Desktop)
  return (
    <div className={`relative w-screen h-screen overflow-hidden bg-white font-sans text-stone-900 grain-overlay transition-all duration-1000`} style={{ filter: isNight ? `brightness(${config.nightMode.dimLevel || 0.9})` : 'brightness(1)' }}>
      {/* Fullscreen Overlay for TV */}
      <AnimatePresence>
        {!isFullscreen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-stone-950/95 backdrop-blur-md flex flex-col items-center justify-center text-center p-12"
          >
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="max-w-md"
            >
              <h1 className="font-playfair text-6xl text-gold-amber italic mb-4">Amsterdam</h1>
              <p className="font-bebas text-sm tracking-[8px] text-stone-500 uppercase mb-12">Sistema de Exibição</p>
              
              <button 
                onClick={toggleFullscreen}
                className="group relative px-12 py-6 bg-transparent border border-gold-amber/30 rounded-full overflow-hidden transition-all hover:border-gold-amber"
              >
                <div className="absolute inset-0 bg-gold-amber/5 group-hover:bg-gold-amber/10 transition-colors" />
                <span className="relative font-bebas text-2xl tracking-[4px] text-gold-amber flex items-center gap-4">
                  <Maximize className="w-6 h-6" /> INICIAR TELA CHEIA
                </span>
              </button>
              
              <p className="mt-12 text-stone-600 text-[10px] font-bebas tracking-widest uppercase leading-relaxed opacity-50">
                Para uma melhor experiência na vitrine,<br/>
                o sistema deve ser executado em modo tela cheia.
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Discrete Edit Button for TV */}
      <button 
        onClick={() => setShowPasswordModal(true)}
        className="fixed bottom-4 right-4 z-50 p-2 text-stone-300/10 hover:text-stone-400 transition-colors"
        title="Configurações"
      >
        <Settings className="w-4 h-4" />
      </button>

      {/* Password Modal */}
      <AnimatePresence>
        {showPasswordModal && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPasswordModal(false)}
              className="absolute inset-0 bg-stone-950/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-white rounded-3xl p-8 w-full max-w-sm shadow-2xl border border-stone-200"
            >
              <h3 className="font-playfair text-2xl text-stone-900 italic mb-2 text-center">Acesso Restrito</h3>
              <p className="font-bebas text-xs tracking-[4px] text-stone-400 text-center mb-8 uppercase">Digite a senha para editar</p>
              
              <div className="space-y-4">
                <p className="text-[9px] text-stone-400 text-center italic mb-2">A senha libera a visualização. Para salvar na nuvem, será necessário conectar sua conta Google.</p>
                <input 
                  type="password"
                  autoFocus
                  placeholder="Senha do Painel"
                  value={tvPasswordInput}
                  onChange={(e) => setTvPasswordInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      if (tvPasswordInput.trim().toLowerCase() === 'systv') {
                        setIsTvAdmin(true);
                        setShowPasswordModal(false);
                        setTvPasswordInput('');
                        setView('dashboard');
                      } else {
                        alert('Senha incorreta');
                      }
                    }
                  }}
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl p-4 text-center text-stone-800 outline-none focus:border-gold-amber transition-colors"
                />
                <button 
                  onClick={() => {
                    if (tvPasswordInput.trim().toLowerCase() === 'systv') {
                      setIsTvAdmin(true);
                      setShowPasswordModal(false);
                      setTvPasswordInput('');
                      setView('dashboard');
                    } else {
                      alert('Senha incorreta');
                    }
                  }}
                  className="w-full bg-gold-amber text-white font-bebas tracking-widest py-4 rounded-xl shadow-lg shadow-gold-amber/20 active:scale-95 transition-all"
                >
                  ENTRAR NO PAINEL
                </button>
                <button 
                  onClick={() => setShowPasswordModal(false)}
                  className="w-full text-stone-400 font-bebas tracking-widest text-xs py-2 hover:text-stone-600 transition-colors"
                >
                  CANCELAR
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Background Glow */}
      <div className="fixed inset-0 z-0 animate-bgshift" style={{
        background: isNight ? `
          radial-gradient(ellipse 80% 60% at 15% 50%, rgba(200,200,200,.03) 0%, transparent 70%),
          radial-gradient(ellipse 60% 80% at 85% 20%, rgba(180,180,180,.02) 0%, transparent 70%),
          linear-gradient(160deg, #f5f5f4 0%, #fafaf9 100%)
        ` : `
          radial-gradient(ellipse 80% 60% at 15% 50%, rgba(245,158,11,.06) 0%, transparent 70%),
          radial-gradient(ellipse 60% 80% at 85% 20%, rgba(245,158,11,.04) 0%, transparent 70%),
          linear-gradient(160deg, #ffffff 0%, #fdfcfb 100%)
        `
      }} />

      <div className="relative z-1 grid w-full h-full grid-cols-[1fr_clamp(280px,28vw,520px)] grid-rows-[1fr_auto]">
        
        {/* Main Slides Area */}
        <div className="relative overflow-hidden bg-black">
          <AnimatePresence mode="wait">
            {config.slides[currentSlideIdx] && (
              <motion.div
                key={currentSlideIdx}
                initial={{ opacity: 0, scale: 1.05 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 1.4 }}
                className="absolute inset-0"
              >
                <SlideContent 
                  slide={config.slides[currentSlideIdx]} 
                  onNext={nextSlide} 
                  onDurationFound={setActiveDuration}
                />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Progress Bar */}
          <motion.div 
            key={`prog-${currentSlideIdx}-${activeDuration}`}
            initial={{ width: '0%' }}
            animate={{ width: '100%' }}
            transition={{ duration: activeDuration, ease: "linear" }}
            className="absolute bottom-0 left-0 h-1 md:h-1.5 bg-linear-to-r from-gold-dark via-gold-amber to-gold-amber shadow-[0_0_12px_rgba(245,158,11,0.4)] z-20"
          />

          {/* Dots */}
          <div className="absolute bottom-4 right-4 md:bottom-7 md:right-10 flex gap-2 z-20">
            {config.slides.map((_, i) => (
              <div 
                key={i} 
                className={`h-2 md:h-3 rounded-full border border-gold-amber/30 transition-all duration-400 ${
                  i === currentSlideIdx ? 'bg-gold-amber w-6 md:w-10 shadow-[0_0_8px_rgba(245,158,11,0.3)]' : 'bg-stone-200 w-2 md:w-3'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Sidebar */}
        <div className="flex flex-col overflow-hidden border-l border-stone-200 bg-white/90 backdrop-blur-md relative">
          {/* Side Glow */}
          <div className="absolute top-0 left-[-1px] w-[1px] h-full bg-linear-to-b from-transparent via-gold-amber/40 to-transparent shadow-[0_0_20px_rgba(245,158,11,0.1)]" />

          {/* Clock Block */}
          <div className="p-4 md:p-10 pb-3 md:pb-7 text-center border-b border-stone-100 bg-[radial-gradient(ellipse_at_50%_0%,rgba(245,158,11,0.03)_0%,transparent_70%)] shrink-0">
            <div className="font-bebas text-6xl md:text-8xl lg:text-9xl leading-[0.85] tracking-widest bg-linear-to-b from-stone-800 via-stone-600 to-gold-amber bg-clip-text text-transparent drop-shadow-[0_0_10px_rgba(245,200,66,0.2)]">
              {timeInfo.hm}
            </div>
            <div className="font-bebas text-2xl md:text-4xl text-gold-amber/60 tracking-widest -mt-1 md:-mt-2">
              {timeInfo.sec}
            </div>
            <div className="font-playfair text-lg md:text-3xl text-stone-600 mt-2 md:mt-4 italic capitalize">
              {timeInfo.day}
            </div>
            <div className="text-[10px] md:text-base font-light text-stone-400 tracking-widest uppercase mt-1">
              {timeInfo.date}
            </div>
          </div>

          {/* Gold Price Block */}
          <div className="p-4 md:p-8 border-b border-stone-100 text-center bg-[radial-gradient(circle_at_center,rgba(201,168,76,0.05)_0%,transparent_70%)] shrink-0 space-y-6">
            <div>
              <div className="font-bebas text-[10px] md:text-xs tracking-[4px] text-stone-400 uppercase mb-1">Ouro 24k (Puro)</div>
              <div className="font-bebas text-2xl md:text-4xl text-stone-800 tracking-wider drop-shadow-[0_0_8px_rgba(201,168,76,0.1)]">
                {goldPrice24k}
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute inset-x-10 top-1/2 -translate-y-1/2 h-[1px] bg-stone-100" />
              <div className="relative z-10 inline-block px-3 bg-white text-[8px] text-stone-300 font-bebas tracking-[3px]">VALORES POR GRAMA</div>
            </div>

            <div>
              <div className="font-bebas text-[10px] md:text-xs tracking-[4px] text-gold-amber uppercase mb-1">Ouro 18k (Joalheria)</div>
              <div className="font-bebas text-3xl md:text-5xl text-stone-900 tracking-wider drop-shadow-[0_0_10px_rgba(201,168,76,0.2)]">
                {goldPrice18k}
              </div>
            </div>

            <div className="text-[8px] md:text-[10px] text-stone-400 font-light tracking-widest uppercase mt-2">
              Cotação em Tempo Real · AwesomeAPI
            </div>
          </div>

          {/* Announcement Block */}
          <div className="p-3 md:p-5 border-b border-stone-100 flex-1 flex flex-col justify-center bg-[radial-gradient(ellipse_at_50%_100%,rgba(245,200,66,0.03)_0%,transparent_70%)] min-h-0">
            <div className="font-bebas text-[10px] md:text-sm tracking-widest text-gold-amber mb-2">Comunicado</div>
            <AnimatePresence mode="wait">
              <motion.div
                key={currentComIdx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.7 }}
                className="text-sm md:text-xl lg:text-2xl font-light italic text-stone-600 leading-relaxed"
              >
                {config.coms[currentComIdx]}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Contact Block */}
          <div className="p-3 md:p-6 shrink-0 text-center bg-white border-t border-stone-100">
            <div className="flex justify-center mb-4">
              <div className="p-2 bg-white rounded-lg shadow-[0_4px_20px_rgba(0,0,0,0.05)] border border-stone-100">
                <QRCodeSVG 
                  value={`https://wa.me/${config.tel.replace(/\D/g, '')}`} 
                  size={100}
                  fgColor="#1c1917"
                  level="H"
                />
              </div>
            </div>
            <div className="font-bebas text-[9px] md:text-xs tracking-[5px] text-gold-amber mb-1.5 uppercase">Escaneie para falar conosco</div>
            <div className="font-bebas text-2xl md:text-4xl lg:text-5xl text-stone-800 tracking-wider whitespace-nowrap drop-shadow-[0_0_10px_rgba(245,200,66,0.15)]">
              {config.tel}
            </div>
            <div className="text-[9px] md:text-sm text-stone-400 mt-1.5 md:mt-2 tracking-widest">
              {config.instagram}
            </div>
          </div>
        </div>

        {/* Ticker Footer */}
        <div className="col-span-2 h-[38px] md:h-[58px] bg-white border-t border-stone-200 overflow-hidden relative flex items-center">
          <div className="absolute left-0 top-0 w-10 md:w-20 h-full z-2 bg-linear-to-r from-white to-transparent pointer-events-none" />
          <div className="absolute right-0 top-0 w-10 md:w-20 h-full z-2 bg-linear-to-l from-white to-transparent pointer-events-none" />
          
          <div className="flex gap-0 animate-ticker whitespace-nowrap">
            {[...config.tickers, ...config.tickers].map((t, i) => (
              <span key={i} className="inline-flex items-center gap-3 md:gap-7 px-5 md:px-12 font-bebas text-sm md:text-2xl tracking-widest text-stone-600 whitespace-nowrap">
                {t}
                <span className="text-gold-amber text-base md:text-3xl opacity-60 drop-shadow-[0_0_10px_rgba(245,200,66,0.4)]">✦</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Dashboard({ config, setConfig, setView, isMobile, isAdmin, isAuthenticated, onAdminLogin, onLogout }: { config: AppConfig, setConfig: (c: AppConfig) => void, setView: (v: 'display' | 'dashboard') => void, isMobile: boolean, isAdmin: boolean, isAuthenticated: boolean, onAdminLogin: () => void, onLogout?: () => void }) {
  const [editingSlide, setEditingSlide] = useState<Slide | null>(null);
  const [activeTab, setActiveTab] = useState<'content' | 'settings'>('content');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    // Check if actually authenticated with Google for Firestore write
    if (!isAuthenticated || !isAdmin) {
      alert("Para salvar as alterações na nuvem, você precisa estar logado com sua conta Google (melkerrubio@gmail.com).");
      onAdminLogin();
      return;
    }
    
    setIsSaving(true);
    try {
      // Clean config for Firestore (remove undefined values)
      const cleanConfig = JSON.parse(JSON.stringify(config));
      await setDoc(doc(db, 'settings', 'global'), cleanConfig);
      if (!isMobile) setView('display');
      alert("Configurações salvas com sucesso!");
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'settings/global');
      alert("Erro ao salvar. Verifique se você está logado como administrador.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 font-sans selection:bg-gold-amber/30 selection:text-stone-900">
      {/* Sidebar */}
      <AnimatePresence>
        {(isSidebarOpen || !isMobile) && (
          <motion.div 
            initial={isMobile ? { x: -300 } : false}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            className="fixed left-0 top-0 bottom-0 w-64 bg-white border-r border-stone-200 flex flex-col p-6 z-50 overflow-y-auto shadow-2xl md:shadow-none"
          >
            <div className="flex justify-between items-center mb-8">
              <div>
                <h1 className="font-playfair text-2xl text-gold-amber italic">Amsterdam</h1>
                <p className="font-bebas text-[10px] tracking-[4px] text-stone-400 uppercase">Dashboard</p>
              </div>
              {isMobile && (
                <button onClick={() => setIsSidebarOpen(false)} className="p-2 text-stone-400">
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>

            {/* Auth Status */}
            <div className="mb-8 p-4 bg-stone-50 rounded-2xl border border-stone-100">
              <p className="font-bebas text-[9px] tracking-[2px] text-stone-400 uppercase mb-2">Status de Sincronização</p>
              {isAuthenticated ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${isAdmin ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
                    <span className="text-[10px] font-medium text-stone-600 uppercase tracking-wider">
                      {isAdmin ? 'Conectado à Nuvem' : 'E-mail não autorizado'}
                    </span>
                  </div>
                  {!isAdmin && (
                    <p className="text-[8px] text-red-400 italic leading-tight">
                      Logado como: {auth.currentUser?.email}. Apenas o administrador pode salvar.
                    </p>
                  )}
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-amber-500" />
                    <span className="text-[10px] font-medium text-stone-600 uppercase tracking-wider">Modo Offline (Senha)</span>
                  </div>
                  <button 
                    onClick={onAdminLogin}
                    className="w-full py-2 bg-white border border-stone-200 rounded-lg text-[9px] font-bebas tracking-widest text-stone-600 hover:bg-stone-100 transition-all flex items-center justify-center gap-2"
                  >
                    <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/action/google.svg" className="w-3 h-3" alt="Google" />
                    CONECTAR GOOGLE
                  </button>
                  <p className="text-[8px] text-stone-400 italic leading-tight">Necessário para salvar alterações na nuvem.</p>
                </div>
              )}
            </div>

            <nav className="flex-1 space-y-2">
              <button 
                onClick={() => {
                  setActiveTab('content');
                  if (isMobile) setIsSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border font-bebas tracking-widest text-sm transition-all ${
                  activeTab === 'content' 
                    ? 'bg-gold-amber/10 text-gold-amber border-gold-amber/20' 
                    : 'text-stone-400 hover:text-stone-600 border-transparent'
                }`}
              >
                <Layout className="w-4 h-4" /> CONTEÚDO
              </button>
              <button 
                onClick={() => {
                  setActiveTab('settings');
                  if (isMobile) setIsSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border font-bebas tracking-widest text-sm transition-all ${
                  activeTab === 'settings' 
                    ? 'bg-gold-amber/10 text-gold-amber border-gold-amber/20' 
                    : 'text-stone-400 hover:text-stone-600 border-transparent'
                }`}
              >
                <Settings className="w-4 h-4" /> AJUSTES
              </button>
            </nav>

            {!isMobile && (
              <div className="mt-8 space-y-2">
                <button 
                  onClick={() => setView('display')}
                  className="w-full flex items-center justify-center gap-2 px-4 py-4 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl border border-stone-200 font-bebas tracking-widest text-sm transition-all shrink-0"
                >
                  <Tv className="w-4 h-4" /> VOLTAR PARA TV
                </button>
                {onLogout && (
                  <button 
                    onClick={onLogout}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 text-red-400 hover:text-red-500 font-bebas tracking-widest text-xs transition-all"
                  >
                    SAIR DO PAINEL
                  </button>
                )}
              </div>
            )}
            
            {isMobile && (
              <div className="mt-auto pt-8 border-t border-stone-100">
                <p className="text-[10px] font-bebas tracking-widest text-stone-300 text-center">
                  AMSTERDAM JOIAS · MOBILE DASHBOARD
                </p>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Top Bar */}
      {isMobile && (
        <div className="fixed top-0 left-0 right-0 h-16 bg-white border-b border-stone-200 flex items-center justify-between px-6 z-40">
          <button onClick={() => setIsSidebarOpen(true)} className="p-2 -ml-2 text-stone-600">
            <Menu className="w-6 h-6" />
          </button>
          <h1 className="font-playfair text-xl text-gold-amber italic">Amsterdam</h1>
          <div className="w-10" /> {/* Spacer */}
        </div>
      )}

      {/* Main Content */}
      <main className={`${isMobile ? 'pt-24' : 'pl-64'} p-6 md:p-12 max-w-7xl mx-auto`}>
        <header className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 gap-6">
          <div>
            <h2 className="text-3xl md:text-4xl font-playfair italic text-stone-900">
              {activeTab === 'content' ? 'Gerenciar Conteúdo' : 'Configurações'}
            </h2>
            <p className="text-stone-400 mt-2 text-sm md:text-base">
              {activeTab === 'content' 
                ? 'Personalize os slides e comunicados da TV.' 
                : 'Ajuste as preferências globais do sistema.'}
            </p>
          </div>
          <div className="flex flex-col md:flex-row gap-3 w-full md:w-auto">
            {isAuthenticated && !isAdmin && (
              <div className="flex flex-col justify-center px-4">
                <p className="text-red-500 text-[10px] font-bebas tracking-widest uppercase">
                  Acesso de Leitura: {auth.currentUser?.email}
                </p>
                <p className="text-stone-400 text-[8px] font-bebas tracking-widest uppercase">
                  Apenas melkerrubio@gmail.com pode salvar
                </p>
              </div>
            )}
            {!isAuthenticated && (
              <button 
                type="button"
                onClick={onAdminLogin}
                className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-stone-900 text-white font-bebas tracking-widest hover:bg-stone-800 transition-all"
              >
                <Lock className="w-4 h-4" /> CONECTAR GOOGLE
              </button>
            )}
            <button 
              type="button"
              onClick={handleSave}
              disabled={isSaving}
              className={`flex-1 md:flex-none px-8 py-3 rounded-xl bg-gold-amber text-white font-bebas tracking-widest shadow-lg shadow-gold-amber/20 active:scale-95 transition-all flex items-center justify-center gap-2 ${isSaving ? 'opacity-50 cursor-not-allowed' : 'animate-pulse-subtle'}`}
            >
              {isSaving ? 'SALVANDO...' : (isMobile ? 'SALVAR TUDO' : 'SALVAR ALTERAÇÕES')}
            </button>
          </div>
        </header>

        <div className="grid grid-cols-1 gap-12">
          {activeTab === 'content' ? (
            <>
              {/* Slides Section */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bebas text-xl tracking-[4px] text-gold-amber flex items-center gap-3">
                <Layout className="w-5 h-5" /> SLIDES EM EXIBIÇÃO
              </h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {config.slides.map((s, i) => (
                <div key={s.id || i} className="group relative bg-white border border-stone-200 rounded-2xl overflow-hidden hover:border-gold-amber/30 transition-all shadow-sm">
                  <div className="aspect-video bg-stone-100 relative">
                    {s.type === 'img' || s.type === 'product' ? (
                      <img src={s.src} className="w-full h-full object-cover opacity-60" referrerPolicy="no-referrer" />
                    ) : s.type === 'youtube' ? (
                      <div className="w-full h-full flex items-center justify-center text-stone-300">
                        <Youtube className="w-12 h-12" />
                      </div>
                    ) : (
                      <div className="w-full h-full" style={{ background: COLOR_SCHEMES[s.color || 'sc-bronze'] }} />
                    )}
                    <div className="absolute top-3 left-3 px-2 py-1 bg-white/80 backdrop-blur-sm rounded text-[10px] font-bebas tracking-widest text-gold-amber border border-gold-amber/20 uppercase">
                      {s.type}
                    </div>
                  </div>
                  <div className="p-4">
                    <h4 className="font-medium truncate text-stone-800">{s.title?.replace(/<[^>]*>/g, '') || 'Sem Título'}</h4>
                    <p className="text-xs text-stone-400 truncate mt-1">{s.sub || 'Sem subtítulo'}</p>
                    <div className="mt-4 flex justify-between items-center">
                      <div className="flex gap-1">
                        <button 
                          onClick={() => {
                            setEditingSlide(s);
                            document.getElementById('slide-form')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                          }}
                          className="p-2 text-stone-400 hover:text-gold-amber hover:bg-gold-amber/5 rounded-lg transition-all"
                          title="Editar"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => {
                            const newSlides = [...config.slides];
                            newSlides.splice(i, 1);
                            setConfig({ ...config, slides: newSlides });
                          }}
                          className="p-2 text-red-400/60 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                          title="Excluir"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <span className="text-[10px] text-stone-300 font-mono uppercase">{s.id?.slice(0, 8)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <NewSlideForm 
              editingSlide={editingSlide}
              onCancel={() => setEditingSlide(null)}
              onAdd={(s) => {
                if (editingSlide) {
                  const newSlides = config.slides.map(item => item.id === editingSlide.id ? s : item);
                  setConfig({ ...config, slides: newSlides });
                  setEditingSlide(null);
                } else {
                  setConfig({ ...config, slides: [...config.slides, s] });
                }
              }} 
            />
          </section>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Announcements */}
            <section>
              <h3 className="font-bebas text-xl tracking-[4px] text-gold-amber flex items-center gap-3 mb-6">
                <MessageSquare className="w-5 h-5" /> COMUNICADOS
              </h3>
              <div className="space-y-3 mb-6">
                {config.coms.map((c, i) => (
                  <div key={i} className="flex items-center gap-4 bg-white border border-stone-200 rounded-xl p-4 group shadow-sm">
                    <p className="flex-1 text-sm text-stone-600 italic">"{c}"</p>
                    <button onClick={() => {
                      const newComs = [...config.coms];
                      newComs.splice(i, 1);
                      setConfig({ ...config, coms: newComs });
                    }} className="text-stone-300 hover:text-red-500 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
              <div className="flex gap-3">
                <input 
                  id="new-com-dash"
                  className="flex-1 bg-white border border-stone-200 rounded-xl p-4 text-stone-800 text-sm outline-none focus:border-gold-amber transition-colors shadow-sm"
                  placeholder="Novo comunicado..."
                />
                <button 
                  onClick={() => {
                    const el = document.getElementById('new-com-dash') as HTMLInputElement;
                    if (!el.value.trim()) return;
                    setConfig({ ...config, coms: [...config.coms, el.value.trim()] });
                    el.value = '';
                  }}
                  className="px-6 py-4 bg-gold-amber/10 text-gold-amber border border-gold-amber/20 rounded-xl font-bebas tracking-widest hover:bg-gold-amber/20 transition-all"
                >
                  ADICIONAR
                </button>
              </div>
            </section>

            {/* Tickers */}
            <section>
              <h3 className="font-bebas text-xl tracking-[4px] text-gold-amber flex items-center gap-3 mb-6">
                <TrendingUp className="w-5 h-5" /> RODAPÉ (TICKER)
              </h3>
              <div className="space-y-3 mb-6">
                {config.tickers.map((t, i) => (
                  <div key={i} className="flex items-center gap-4 bg-white border border-stone-200 rounded-xl p-4 group shadow-sm">
                    <p className="flex-1 text-sm text-stone-600 font-bebas tracking-widest">{t}</p>
                    <button onClick={() => {
                      const newTickers = [...config.tickers];
                      newTickers.splice(i, 1);
                      setConfig({ ...config, tickers: newTickers });
                    }} className="text-stone-300 hover:text-red-500 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
              <div className="flex gap-3">
                <input 
                  id="new-ticker-dash"
                  className="flex-1 bg-white border border-stone-200 rounded-xl p-4 text-stone-800 text-sm outline-none focus:border-gold-amber transition-colors shadow-sm"
                  placeholder="Novo ticker..."
                />
                <button 
                  onClick={() => {
                    const el = document.getElementById('new-ticker-dash') as HTMLInputElement;
                    if (!el.value.trim()) return;
                    setConfig({ ...config, tickers: [...config.tickers, el.value.trim()] });
                    el.value = '';
                  }}
                  className="px-6 py-4 bg-gold-amber/10 text-gold-amber border border-gold-amber/20 rounded-xl font-bebas tracking-widest hover:bg-gold-amber/20 transition-all"
                >
                  ADICIONAR
                </button>
              </div>
            </section>
              </div>
            </>
          ) : (
            /* Settings Grid */
            <section className="bg-white border border-stone-200 rounded-3xl p-8 md:p-12 shadow-sm">
            <h3 className="font-bebas text-2xl tracking-[6px] text-gold-amber mb-12 text-center">CONFIGURAÇÕES DO SISTEMA</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
              <div className="space-y-6">
                <h4 className="font-bebas text-stone-400 tracking-widest text-sm border-b border-stone-100 pb-2">GERAL</h4>
                <div className="space-y-4">
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] text-stone-400 uppercase tracking-widest">Duração Slide (seg)</label>
                    <input type="number" value={config.dur} onChange={e => setConfig({...config, dur: parseInt(e.target.value) || 3})} className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber" />
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] text-stone-400 uppercase tracking-widest">WhatsApp</label>
                    <input value={config.tel} onChange={e => setConfig({...config, tel: e.target.value})} className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber" />
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <h4 className="font-bebas text-stone-400 tracking-widest text-sm border-b border-stone-100 pb-2">SOCIAL & WEB</h4>
                <div className="space-y-4">
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] text-stone-400 uppercase tracking-widest">Instagram</label>
                    <input value={config.instagram} onChange={e => setConfig({...config, instagram: e.target.value})} className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber" />
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] text-stone-400 uppercase tracking-widest">Website</label>
                    <input value={config.site} onChange={e => setConfig({...config, site: e.target.value})} className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber" />
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <h4 className="font-bebas text-stone-400 tracking-widest text-sm border-b border-stone-100 pb-2">MODO NOTURNO</h4>
                <div className="bg-stone-50 p-6 rounded-2xl border border-stone-100 space-y-6">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-stone-500 font-bebas tracking-widest">STATUS</span>
                    <button 
                      onClick={() => setConfig({...config, nightMode: {...config.nightMode, enabled: !config.nightMode.enabled}})}
                      className={`px-4 py-1 rounded-full text-[10px] font-bold tracking-widest transition-all ${config.nightMode.enabled ? 'bg-gold-amber text-white' : 'bg-stone-200 text-stone-400'}`}
                    >
                      {config.nightMode.enabled ? 'ATIVADO' : 'DESATIVADO'}
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] text-stone-400 uppercase tracking-widest">INÍCIO</label>
                      <input type="number" value={config.nightMode.startHour} onChange={e => setConfig({...config, nightMode: {...config.nightMode, startHour: parseInt(e.target.value) || 0}})} className="bg-white border border-stone-200 rounded-lg p-3 text-stone-800 text-center" />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] text-stone-400 uppercase tracking-widest">FIM</label>
                      <input type="number" value={config.nightMode.endHour} onChange={e => setConfig({...config, nightMode: {...config.nightMode, endHour: parseInt(e.target.value) || 0}})} className="bg-white border border-stone-200 rounded-lg p-3 text-stone-800 text-center" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="space-y-6">
                <h4 className="font-bebas text-stone-400 tracking-widest text-sm border-b border-stone-100 pb-2">SEGURANÇA</h4>
                <div className="space-y-4">
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] text-stone-400 uppercase tracking-widest">Senha do Painel</label>
                    <input 
                      type="text" 
                      value={config.password || ''} 
                      onChange={e => setConfig({...config, password: e.target.value})} 
                      className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber" 
                      placeholder="Senha de acesso"
                    />
                  </div>
                </div>
              </div>
            </div>
          </section>
          )}
        </div>
      </main>
    </div>
  );
}

function SlideContent({ slide, onNext, onDurationFound }: { slide: Slide, onNext: () => void, onDurationFound?: (d: number) => void }) {
  if (slide.type === 'youtube') {
    // Standard YouTube embed with autoplay, mute, and loop
    const embedUrl = `https://www.youtube.com/embed/${slide.youtubeId}?autoplay=1&mute=1&controls=0&loop=1&playlist=${slide.youtubeId}&modestbranding=1&rel=0&iv_load_policy=3`;
    
    return (
      <div className="w-full h-full relative bg-black overflow-hidden">
        <iframe 
          src={embedUrl}
          className="w-full h-full border-0 pointer-events-none scale-[1.35]"
          allow="autoplay; encrypted-media"
          title="YouTube video player"
        />
        <div className="absolute inset-0 bg-linear-to-b from-white/10 via-transparent to-black/20 z-1 pointer-events-none" />
        <SlideCaption slide={slide} />
      </div>
    );
  }

  if (slide.type === 'product') {
    return (
      <div className="w-full h-full flex items-center justify-center p-8 md:p-20 bg-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,var(--color-gold-amber)_0%,transparent_70%)]" />
        </div>
        
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-12 items-center max-w-7xl w-full">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            className="order-2 md:order-1"
          >
            <SlideCaption slide={slide} inline />
            {slide.price && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="mt-8"
              >
                <div className="text-gold-amber/60 font-bebas text-xl tracking-widest uppercase mb-1">Investimento</div>
                <div className="text-stone-900 font-bebas text-5xl md:text-7xl lg:text-8xl tracking-tighter">
                  {slide.price}
                </div>
                <div className="text-stone-400 text-sm md:text-lg mt-2 font-light italic">
                  *Consulte condições de parcelamento
                </div>
              </motion.div>
            )}
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            className="order-1 md:order-2 flex justify-center"
          >
            <div className="relative group">
              <div className="absolute -inset-4 bg-gold-amber/10 blur-3xl rounded-full group-hover:bg-gold-amber/20 transition-all duration-1000" />
              <img 
                src={slide.src} 
                alt={slide.title} 
                className="relative w-full max-w-[500px] aspect-square object-cover rounded-2xl border border-stone-200 shadow-xl animate-float"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  if (slide.type === 'img') {
    const isGif = slide.src?.toLowerCase().includes('.gif');
    return (
      <div className="w-full h-full relative">
        {isGif ? (
          <img src={slide.src} alt="" className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-cover bg-center" style={{ backgroundImage: `url(${slide.src})` }} />
        )}
        <div className="absolute inset-0 bg-linear-to-b from-white/10 via-transparent to-black/20 z-1" />
        <SlideCaption slide={slide} />
      </div>
    );
  }

  if (slide.type === 'video') {
    return (
      <div className="w-full h-full relative">
        <video 
          src={slide.src} 
          autoPlay 
          muted 
          playsInline 
          className="w-full h-full object-cover" 
          onLoadedMetadata={(e) => {
            if (onDurationFound) onDurationFound(e.currentTarget.duration);
          }}
          onEnded={onNext}
        />
        <div className="absolute inset-0 bg-linear-to-b from-white/10 via-transparent to-black/20 z-1" />
        <SlideCaption slide={slide} />
      </div>
    );
  }

  return (
    <div 
      className={`w-full h-full flex flex-col justify-center p-8 md:p-24 relative overflow-hidden ${slide.color || 'sc-bronze'}`}
      style={{ background: COLOR_SCHEMES[slide.color || 'sc-bronze'] }}
    >
      <div 
        className="absolute w-[300px] h-[300px] md:w-[600px] md:h-[600px] lg:w-[900px] lg:h-[900px] rounded-full -top-[20%] -right-[15%] pointer-events-none"
        style={{ background: `radial-gradient(circle, ${ACCENT_COLORS[slide.color || 'sc-bronze']} 0%, transparent 70%)` }}
      />
      <SlideCaption slide={slide} inline />
    </div>
  );
}

function SlideCaption({ slide, inline = false }: { slide: Slide, inline?: boolean }) {
  const content = (
    <div className={inline ? "" : "absolute bottom-10 left-10 md:bottom-20 md:left-20 z-10 max-w-[85%] md:max-w-[860px]"}>
      {slide.tag && (
        <motion.span 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-block font-bebas text-sm md:text-xl lg:text-2xl tracking-[4px] md:tracking-[8px] text-gold-amber bg-gold-amber/10 border border-gold-amber/30 rounded px-4 py-1 mb-3 md:mb-5 drop-shadow-[0_0_10px_rgba(245,200,66,0.2)]"
        >
          {slide.tag}
        </motion.span>
      )}
      {slide.title && (
        <>
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: 64 }}
            className="h-1 bg-linear-to-r from-gold-dark via-gold-amber to-gold-amber rounded-full mb-3 md:mb-5 shadow-[0_0_8px_rgba(245,200,66,0.3)]" 
          />
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-playfair text-4xl md:text-7xl lg:text-9xl font-black leading-[0.93] text-stone-900 drop-shadow-[0_4px_20px_rgba(0,0,0,0.1)] tracking-tight"
            dangerouslySetInnerHTML={{ __html: slide.title }}
          />
        </>
      )}
      {slide.sub && (
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-base md:text-2xl lg:text-4xl font-serif italic text-stone-600 mt-3 md:mt-6 leading-tight drop-shadow-[0_2px_8px_rgba(0,0,0,0.05)]"
        >
          {slide.sub}
        </motion.p>
      )}
    </div>
  );

  return content;
}

function NewSlideForm({ onAdd, editingSlide, onCancel }: { onAdd: (s: Slide) => void, editingSlide?: Slide | null, onCancel?: () => void }) {
  const [type, setType] = useState<SlideType>('color');
  const [src, setSrc] = useState('');
  const [youtubeId, setYoutubeId] = useState('');
  const [color, setColor] = useState('sc-bronze');
  const [title, setTitle] = useState('');
  const [sub, setSub] = useState('');
  const [tag, setTag] = useState('');
  const [price, setPrice] = useState('');
  const [duration, setDuration] = useState('');

  useEffect(() => {
    if (editingSlide) {
      setType(editingSlide.type);
      setSrc(editingSlide.src || '');
      setYoutubeId(editingSlide.youtubeId || '');
      setColor(editingSlide.color || 'sc-bronze');
      setTitle(editingSlide.title || '');
      setSub(editingSlide.sub || '');
      setTag(editingSlide.tag || '');
      setPrice(editingSlide.price || '');
      setDuration(editingSlide.duration ? String(editingSlide.duration) : '');
    } else {
      setType('color');
      setSrc('');
      setYoutubeId('');
      setColor('sc-bronze');
      setTitle('');
      setSub('');
      setTag('');
      setPrice('');
      setDuration('');
    }
  }, [editingSlide]);

  const handleAdd = () => {
    if (type === 'youtube' && !youtubeId) return alert('Informe o ID do vídeo do YouTube.');
    if (type !== 'color' && type !== 'youtube' && !src) return alert('Informe a URL da mídia.');
    if (!title && !src && type !== 'youtube') return alert('Informe um título ou mídia.');
    
    const safeId = () => {
      try {
        return crypto.randomUUID();
      } catch (e) {
        return Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
      }
    };

    onAdd({ 
      id: editingSlide?.id || safeId(), 
      type, 
      src: type === 'youtube' ? '' : src, 
      youtubeId: type === 'youtube' ? youtubeId : '', 
      color: type === 'color' ? color : '', 
      title, 
      sub, 
      tag, 
      price: type === 'product' ? price : '',
      duration: duration ? parseInt(duration) : undefined
    });

    alert(editingSlide ? "Slide atualizado na lista!" : "Novo slide adicionado à lista! Lembre-se de clicar em 'SALVAR TUDO' no topo para aplicar na TV.");

    if (!editingSlide) {
      setSrc('');
      setYoutubeId('');
      setTitle('');
      setSub('');
      setTag('');
      setPrice('');
      setDuration('');
    }
  };

  return (
    <div className={`space-y-6 bg-white border p-8 rounded-3xl mt-12 shadow-sm transition-all duration-500 ${editingSlide ? 'border-gold-amber ring-4 ring-gold-amber/5' : 'border-stone-200'}`} id="slide-form">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-3">
          <h4 className="font-bebas text-xl tracking-[4px] text-gold-amber">
            {editingSlide ? 'EDITAR CONTEÚDO' : 'ADICIONAR NOVO CONTEÚDO'}
          </h4>
          {editingSlide && (
            <span className="px-2 py-0.5 bg-gold-amber text-white text-[10px] font-bebas tracking-widest rounded animate-pulse">
              MODO EDIÇÃO
            </span>
          )}
        </div>
        {editingSlide && (
          <button onClick={onCancel} className="text-stone-400 hover:text-stone-600 p-2">
            <X className="w-5 h-5" />
          </button>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="flex flex-col gap-2">
          <label className="text-[10px] text-stone-400 uppercase tracking-widest">Tipo de Slide</label>
          <select 
            value={type}
            onChange={(e) => setType(e.target.value as SlideType)}
            className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber"
          >
            <option value="color">Cor / Texto</option>
            <option value="product">Produto (Destaque)</option>
            <option value="youtube">Vídeo do YouTube</option>
            <option value="img">Imagem ou GIF (URL)</option>
            <option value="video">Vídeo Direto (URL)</option>
          </select>
        </div>

        {type === 'color' ? (
          <div className="flex flex-col gap-2">
            <label className="text-[10px] text-stone-400 uppercase tracking-widest">Paleta de Cores</label>
            <select 
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber"
            >
              <option value="sc-bronze">Bronze / Ouro</option>
              <option value="sc-azul">Azul Noite</option>
              <option value="sc-vinho">Vinho / Rubi</option>
              <option value="sc-verde">Verde Esmeralda</option>
              <option value="sc-roxo">Roxo / Ametista</option>
              <option value="sc-cinza">Cinza Grafite</option>
            </select>
          </div>
        ) : type === 'youtube' ? (
          <div className="flex flex-col gap-2">
            <label className="text-[10px] text-stone-400 uppercase tracking-widest">ID do Vídeo YouTube</label>
            <input 
              value={youtubeId}
              onChange={(e) => setYoutubeId(e.target.value)}
              placeholder="Ex: dQw4w9WgXcQ"
              className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber"
            />
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            <label className="text-[10px] text-stone-400 uppercase tracking-widest">Link da Imagem ou Vídeo (URL)</label>
            <input 
              value={src}
              onChange={(e) => setSrc(e.target.value)}
              placeholder="https://exemplo.com/imagem.jpg"
              className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber"
            />
            <p className="text-[9px] text-stone-400 italic">Dica: Use links do Google Drive, Dropbox ou sites de imagens.</p>
            <div className="mt-2 p-3 bg-stone-50 rounded-xl border border-stone-100">
              <p className="text-[9px] text-stone-500 font-medium uppercase tracking-wider mb-1">Como obter o link direto:</p>
              <ul className="text-[9px] text-stone-400 space-y-1 list-disc pl-3">
                <li><strong>Google Drive:</strong> Clique em Compartilhar {'>'} Qualquer pessoa com o link {'>'} Copiar link.</li>
                <li><strong>Imgur/Postimages:</strong> Use o "Link Direto" (termina em .jpg ou .png).</li>
                <li><strong>WhatsApp:</strong> Não use links temporários do WhatsApp Web.</li>
              </ul>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="flex flex-col gap-2">
          <label className="text-[10px] text-stone-400 uppercase tracking-widest">Título</label>
          <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Ex: Alianças de Ouro" className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber" />
        </div>
        <div className="flex flex-col gap-2">
          <label className="text-[10px] text-stone-400 uppercase tracking-widest">Subtítulo</label>
          <input value={sub} onChange={e => setSub(e.target.value)} placeholder="Ex: Ouro 18k" className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber" />
        </div>
        <div className="flex flex-col gap-2">
          <label className="text-[10px] text-stone-400 uppercase tracking-widest">Etiqueta</label>
          <input value={tag} onChange={e => setTag(e.target.value)} placeholder="Ex: ✦ NOVIDADE ✦" className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber" />
        </div>
        {type === 'product' && (
          <div className="flex flex-col gap-2">
            <label className="text-[10px] text-stone-400 uppercase tracking-widest">Preço</label>
            <input value={price} onChange={e => setPrice(e.target.value)} placeholder="Ex: R$ 1.290,00" className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber" />
          </div>
        )}
        <div className="flex flex-col gap-2">
          <label className="text-[10px] text-stone-400 uppercase tracking-widest">Duração (seg)</label>
          <input type="number" value={duration} onChange={e => setDuration(e.target.value)} placeholder="Padrão do sistema" className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 outline-none focus:border-gold-amber" />
        </div>
      </div>

      <div className="flex gap-4">
        {editingSlide && (
          <button 
            onClick={onCancel}
            className="flex-1 bg-stone-100 text-stone-600 font-bebas tracking-widest py-4 rounded-xl hover:bg-stone-200 transition-all"
          >
            CANCELAR EDIÇÃO
          </button>
        )}
        <button 
          type="button"
          onClick={handleAdd}
          className={`${editingSlide ? 'flex-1' : 'w-full'} bg-gold-amber text-white font-bebas tracking-widest py-4 rounded-xl shadow-lg shadow-gold-amber/20 hover:scale-[1.02] transition-transform`}
        >
          {editingSlide ? 'SALVAR ALTERAÇÕES' : 'ADICIONAR AO DISPLAY'}
        </button>
      </div>
    </div>
  );
}
