export type SlideType = 'color' | 'img' | 'video' | 'product' | 'youtube';

export interface Slide {
  id: string;
  type: SlideType;
  color?: string;
  src?: string;
  youtubeId?: string;
  title?: string;
  sub?: string;
  tag?: string;
  price?: string;
  duration?: number;
}

export interface AppConfig {
  dur: number;
  tel: string;
  site: string;
  instagram: string;
  password?: string;
  slides: Slide[];
  coms: string[];
  tickers: string[];
  nightMode: {
    enabled: boolean;
    startHour: number;
    endHour: number;
    dimLevel: number;
  };
}
